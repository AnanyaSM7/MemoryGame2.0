function chooseMode(mode) {
  alert(`You selected the ${mode.toUpperCase()} mode! 🎉`);
  // Later: redirect to levels page
  // window.location.href = `${mode}-levels.html`;
}
